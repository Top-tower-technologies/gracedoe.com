<?php

namespace App\Controllers;

use App\Models\AgentModel;
use CodeIgniter\Controller;

class AgentController extends BaseController
{
    public function index()
    {
        // Ensure the agent is logged in
        if (!session()->get('logged_in_agent')) {
            return redirect()->to('/agent/login'); // Redirect to login if not logged in
        }

        $agentId = session()->get('agent_id'); // Get the logged-in agent's ID
        $propertyModel = new \App\Models\PropertyModel(); // Load the PropertyModel

        // Get search query
        $query = $this->request->getGet('query');

        // Check if a search query is provided
        if ($query) {
            // Search properties by title, address, or type for the specific agent
            $data['properties'] = $propertyModel->where('agent_id', $agentId)
                ->like('title', $query)
                ->orLike('address', $query)
                ->orLike('type', $query)
                ->findAll();
        } else {
            // If no search query, fetch all properties for the agent
            $data['properties'] = $propertyModel->where('agent_id', $agentId)->findAll();
        }

        return view('agent/index', $data); // Load the view with properties data
    }

    public function agents()
    {
        $agentModel = new AgentModel();
        $data['agents'] = $agentModel->findAll();

        return view('agent/agents', $data);


    }


    public function create()
    {
        return view('agent/create');
    }

    public function store()
    {
        if (
            $this->validate([
                'name' => 'required',
                'email' => 'required|valid_email|is_unique[agents.email]',
                'phone' => 'required',
                'password' => 'required',

            ])
        ) {
            $model = new AgentModel();
            $model->save([
                'name' => $this->request->getPost('name'),
                'email' => $this->request->getPost('email'),
                'phone' => $this->request->getPost('phone'),
                'password' => md5($this->request->getPost('password')),
            ]);

            return redirect()->to('/admin/agent')->with('success', 'Agent added successfully');
        } else {
            return view('agent/create', ['validation' => $this->validator]);
        }
    }

    public function edit($id)
    {
        $model = new AgentModel();
        $data['agent'] = $model->find($id);

        if (empty($data['agent'])) {
            return redirect()->to('/admin')->with('error', 'Agent not found');
        }

        return view('agent/edit', $data);
    }

    public function update($id)
    {
        $model = new AgentModel();

        // Proper syntax for is_unique rule with exclusion of current ID
        $rules = [
            'name' => 'required',
            'email' => [
                'rules' => "required|valid_email|is_unique[agents.email,id,{$id}]",
                'errors' => [
                    'is_unique' => 'The email is already in use.',
                ],
            ],
            'phone' => 'required',
        ];

        if ($this->validate($rules)) {
            $data = [
                'name' => $this->request->getPost('name'),
                'email' => $this->request->getPost('email'),
                'phone' => $this->request->getPost('phone'),
            ];

            $model->update($id, $data);

            return redirect()->to('/admin/agents')->with('success', 'Agent updated successfully');
        } else {
            // Re-render edit view with validation errors
            return view('agent/edit', [
                'agent' => $model->find($id),
                'validation' => $this->validator,
            ]);
        }
    }


    public function delete($id)
    {
        $model = new AgentModel();
        if ($model->delete($id)) {
            return redirect()->to('/agent')->with('success', 'Agent deleted successfully');
        } else {
            return redirect()->to('/agent')->with('error', 'Failed to delete agent');
        }
    }

    public function login()
    {
        return view('agent/login'); // Load the login form view
    }

    public function authenticate()
    {

        $model = new AgentModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');



        // Find agent by email
        $agent = $model->where('email', $email)->first();

        if ($agent) {

            // Verify password (assuming passwords are hashed)
            if (md5($password) == $agent['password']) {

                // Set session data for the agent
                session()->set([
                    'agent_id' => $agent['id'],
                    'agent_name' => $agent['name'],
                    'logged_in_agent' => true
                ]);

                return redirect()->to('/agent')->with('success', 'Logged in successfully');
            } else {
                return redirect()->back()->with('error', 'Invalid password');
            }
        } else {
            return redirect()->back()->with('error', 'Agent not found');
        }
    }


    // Logout method
    public function logout()
    {
        session()->destroy(); // Destroy session data
        return redirect()->to('/agent/login')->with('success', 'Logged out successfully');
    }
}
