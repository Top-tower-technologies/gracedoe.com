<?php

namespace App\Controllers;
use App\Models\AdminModel;

use CodeIgniter\Controller;

class AdminController extends BaseController
{
    public function index()
    {
      // Ensure the agent is logged in
      if (!session()->get('logged_in_admin')) {
        return redirect()->to('/admin/login'); // Redirect to login if not logged in
    }
        return view('admin/index');
    }

    public function login()
    {
        return view('admin/login'); // Load admin login view
    }

    public function authenticate()
    {
        $model = new AdminModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');



        // Find agent by email
        $admin = $model->where('email', $email)->first();

        if ($admin) {

            // Verify password (assuming passwords are hashed)
            if (md5($password) == $admin['password']) {

                // Set session data for the admin
                session()->set([
                    'admin_id' => $admin['id'],
                    'admin_name' => $admin['name'],
                    'logged_in_admin' => true
                ]);

                return redirect()->to('/admin')->with('success', 'Logged in successfully');
            } else {
                return redirect()->back()->with('error', 'Invalid password');
            }
        } else {
            return redirect()->back()->with('error', 'Admin not found');
        }
    }

    public function logout()
    {
        session()->destroy(); // Clear all session data
        return redirect()->to('/admin/login')->with('success', 'Logged out successfully');
    }
}
