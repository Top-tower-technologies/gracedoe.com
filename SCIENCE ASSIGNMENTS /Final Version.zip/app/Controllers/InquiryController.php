<?php

namespace App\Controllers;
use App\Models\InquiryModel;
use CodeIgniter\Controller;

class InquiryController extends BaseController
{

    public function leads()
    {
        // Load the LeadModel
        $leadModel = new InquiryModel();

        // Fetch all leads
        $data['leads'] = $leadModel->findAll();

        // Pass leads data to the view
        return view('inquiry/leads', $data);
    }
    public function UnclaimLead()
    {
        $id = $this->request->getPost('id'); // Get the lead ID from the AJAX request
        $leadModel = new InquiryModel();

        if ($id) {
            $lead = $leadModel->find($id);
            if ($lead) {
                // Use the correct structure for the update method
                $leadModel->set(['claim' => 0, 'agent_id' => null])->where('id', $id)->update();
                return $this->response->setJSON(['success' => true, 'message' => 'Lead unclaimed successfully']);
            }
        }

        return $this->response->setJSON(['success' => false, 'message' => 'Failed to unclaim lead']);
    }

    public function updateStatus()
    {
        $id = $this->request->getPost('id');
        $status = $this->request->getPost('status');
        $leadModel = new InquiryModel();
        
        // Update the lead status
        if ($leadModel->where('id', $id)->set(['status' => $status])->update()) {
            return $this->response->setJSON(['success' => true]);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Failed to update status']);
        }
    }



    public function claimLead()
    {
        $id = $this->request->getPost('id'); // Get the lead ID from the AJAX request
        $agentId = $_SESSION['agent_id'];   // Get the agent ID from the session

        // Validate that the ID is provided and is an integer
        if (!$id || !is_numeric($id)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Invalid lead ID.'
            ]);
        }

        // Initialize the model
        $leadModel = new InquiryModel();

        // Check if the lead exists
        $lead = $leadModel->find($id);
        if (!$lead) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Lead not found.'
            ]);
        }

        // Check if the lead is already claimed
        if ($lead['claim'] == 1) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Lead is already claimed.'
            ]);
        }

        // Attempt to update the claim status
        if (
            $leadModel->set([
                'claim' => 1,
                'agent_id' => $agentId,
            ])->where('id', $id)->update()
        ) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Lead claimed successfully.'
            ]);
        }

        // Handle the case where the update fails
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Failed to claim lead. Please try again later.'
        ]);
    }

    public function claimed()
    {
        // Load the InquiryModel
        $leadModel = new InquiryModel();
        $agent_id = $_SESSION['agent_id'];

        // Fetch all leads claimed by the current agent
        $data['leads'] = $leadModel->where('agent_id', $agent_id)->findAll();

        return view('inquiry/claimed', $data);
    }

    public function store()
    {
        $validation = \Config\Services::validation();

        // Validation rules
        $validation->setRules([
            'firstName' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'message' => 'required|min_length[10]'
        ]);

        if (!$this->validate($validation->getRules())) {
            // Validation failed
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Save the inquiry
        $inquiryModel = new InquiryModel();
        $inquiryModel->save([
            'firstName' => $this->request->getPost('firstName'),
            'lastName' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'message' => $this->request->getPost('message'),
        ]);

        return redirect()->to('/')->with('success', 'Your inquiry has been submitted successfully!');
    }
}
