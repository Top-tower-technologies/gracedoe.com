<?php

namespace App\Controllers;
use App\Models\PropertyModel;

class Home extends BaseController
{
    public function index(): string
    {
        $model = new PropertyModel();
        $data['properties'] = $model->findAll();
        return view('index', $data);
    }
}
