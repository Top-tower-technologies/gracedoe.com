<?php

namespace App\Controllers;

use App\Models\PropertyModel;
use CodeIgniter\Controller;

class PropertyController extends BaseController
{
    private $model;

    public function __construct()
    {
        $this->model = new PropertyModel();
    }
    private function handleImages($imageFiles)
    {
        $imagePaths = [];

        // Ensure $imageFiles is an array and contains file objects
        foreach ($imageFiles as $file) {
            if ($file->isValid() && !$file->hasMoved()) {
                // Generate a random name for each image
                $newName = $file->getRandomName();
                // Move the file to the 'uploads' folder
                $file->move(FCPATH . 'uploads', $newName);
                // Add the relative path of the uploaded image to the array
                $imagePaths[] = '/uploads/' . $newName;
            }
        }

        return $imagePaths;
    }



    private function handleUpdatedImages($imageFiles, $existingImages)
    {
        // If new images are uploaded, handle them and return the updated images as JSON
        if (!empty($imageFiles[0]) && $imageFiles[0]->isValid()) {
            return json_encode($this->handleImages($imageFiles));
        }

        // If no new images, return the existing image paths as they are
        return $existingImages;
    }

    private function getFirstSegment()
    {
        $uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
        $segments = explode('/', $uri);
        return ($segments[0] === 'index.php') ? ($segments[1] ?? '') : $segments[0];
    }

    public function index()
    {
        $query = $this->request->getGet('query');
        $data['properties'] = $query
            ? $this->model->like('title', $query)->orLike('address', $query)->findAll()
            : $this->model->findAll();

        return view('property/index', $data);
    }

    public function create()
    {
        return view('property/create');
    }
    public function store()
    {
        // Define validation rules
        $validationRules = [
            'title' => 'required',
            'description' => 'required',
            'price' => 'required|decimal',
            'address' => 'required',
            'agent_id' => 'required|integer',
            'type' => 'required|in_list[sell,rent]',
            'images' => 'uploaded[images]|max_size[images,2048]|ext_in[images,jpg,jpeg,png]',
        ];

        // Validate the form data
        if (!$this->validate($validationRules)) {
            // Log validation errors for debugging
            log_message('error', 'Validation failed: ' . print_r($this->validator->getErrors(), true));
            return view('property/create', [
                'validation' => $this->validator,
                'errors' => $this->validator->getErrors(), // Pass errors to view
            ]);
        }

        $uploadedFiles = $this->request->getFiles('images');

        // Debug: Check the structure of uploaded files
        log_message('debug', 'Uploaded Files: ' . print_r($uploadedFiles, true));

        if (!empty($uploadedFiles)) {
            // Ensure we pass the array of files correctly
            $imagePaths = $this->handleImages($uploadedFiles['images']);
        } else {
            $imagePaths = [];
            log_message('warning', 'No files uploaded.');
        }

        // Prepare the data to be saved in the database
        $data = [
            'title' => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'price' => $this->request->getPost('price'),
            'address' => $this->request->getPost('address'),
            'agent_id' => $_SESSION['agent_id'],
            'type' => $this->request->getPost('type'),
            'images' => json_encode($imagePaths), // Convert image paths to JSON
        ];

        // Debugging: Log the data to be saved
        log_message('info', 'Data to be saved: ' . print_r($data, true));

        // Attempt to save the property
        if ($this->model->save($data)) {
            return redirect()->to($this->getFirstSegment() . '/property')->with('success', 'Property created successfully');
        } else {
            // If save fails, log the error and show an error message
            log_message('error', 'Failed to save property: ' . print_r($this->model->errors(), true));
            return redirect()->back()->with('error', 'Failed to save property.');
        }
    }





    public function edit($id)
    {
        $data['property'] = $this->model->find($id);
        return view('property/edit', $data);
    }

    public function update($id)
    {
        $property = $this->model->find($id);
        if (!$property) {
            return redirect()->to($this->getFirstSegment() . '/property')->with('error', 'Property not found');
        }

        $validationRules = [
            'title' => 'required',
            'description' => 'required',
            'price' => 'required|decimal',
            'address' => 'required',
            'agent_id' => 'required|integer',
            'type' => 'required|in_list[sell,rent]',
            'images' => 'max_size[images,2048]|ext_in[images,jpg,jpeg,png]',
        ];

        if ($this->validate($validationRules)) {
            $data = [
                'title' => $this->request->getPost('title'),
                'description' => $this->request->getPost('description'),
                'price' => $this->request->getPost('price'),
                'address' => $this->request->getPost('address'),
                'agent_id' => $this->request->getPost('agent_id'),
                'type' => $this->request->getPost('type'),
                'images' => $this->handleUpdatedImages($this->request->getFiles('images'), $property['images']),
            ];

            $this->model->update($id, $data);
            return redirect()->to($this->getFirstSegment() . '/property')->with('success', 'Property updated successfully');
        }

        return view('property/edit', ['property' => $property, 'validation' => $this->validator]);
    }

    public function delete($id)
    {
        $this->model->delete($id);
        return redirect()->to($this->getFirstSegment() . '/property');
    }

}
