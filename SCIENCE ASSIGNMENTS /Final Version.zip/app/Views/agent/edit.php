<?= view('admin/header'); ?>

<div class="container mt-5">

    <div class="row">
        <div class="card col-12 p-5 mb-3 shadow">
            <h2 class="mb-4">Edit Agent</h2>

            <form action="/admin/agent/update/<?= $agent['id']; ?>" method="post" class="form-validate">
                <?= csrf_field(); ?> <!-- CSRF token for security -->

                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= esc($agent['name']); ?>"
                        required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email"
                        value="<?= esc($agent['email']); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone</label>
                    <input type="tel" class="form-control" id="phone" name="phone" value="<?= esc($agent['phone']); ?>"
                        required>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="/admin" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>


<?= view('admin/footer'); ?>