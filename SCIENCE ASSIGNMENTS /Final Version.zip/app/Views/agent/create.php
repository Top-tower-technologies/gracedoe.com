<?= view('admin/header'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Add Property</h2>

    <form method="post" action="/admin/agents/store" enctype="multipart/form-data">
        <div class="row">
            <!-- Name Field -->
            <div class="col-md-6 mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" required>
            </div>

            <!-- Email Field -->
            <div class="col-md-6 mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email"
                    required>
            </div>
        </div>

        <div class="row">
            <!-- Password Field -->
            <div class="col-md-6 mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password"
                    placeholder="Enter your password" required>
            </div>

            <!-- Phone Field -->
            <div class="col-md-6 mb-3">
                <label for="phone" class="form-label">Phone</label>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter your phone number"
                    required>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="row mb-5">
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>

</div>

<?= view('admin/footer'); ?>