<?= view('admin/header'); ?>
<div class="container mt-5">
    <h2 class="mb-4">Agents List</h2>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($agents)): ?>
                <?php foreach ($agents as $index => $agent): ?>
                    <tr>
                        <td><?= $index + 1; ?></td>
                        <td><?= esc($agent['name']); ?></td>
                        <td><?= esc($agent['email']); ?></td>
                        <td><?= esc($agent['phone']); ?></td>
                        <td><a href="/admin/agents/edit/<?= esc($agent['id']); ?>" class="btn btn-primary">EDIT</a></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">No agents found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?= view('admin/footer'); ?>
