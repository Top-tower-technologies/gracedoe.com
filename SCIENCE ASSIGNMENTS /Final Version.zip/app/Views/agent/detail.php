<h3>Inquire About This Property</h3>
<form method="post" action="/inquiry/store">
    <input type="hidden" name="property_id" value="<?= $property['id'] ?>">
    <label>Name</label><input type="text" name="customer_name">
    <label>Email</label><input type="text" name="customer_email">
    <label>Message</label><textarea name="message"></textarea>
    <button type="submit">Send Inquiry</button>
</form>