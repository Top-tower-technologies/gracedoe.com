<?php
// Get the full request URI
$requestUri = $_SERVER['REQUEST_URI'];

// Remove any query parameters
$cleanUri = strtok($requestUri, '?');

// Trim leading and trailing slashes
$cleanUri = trim($cleanUri, '/');

// Split the URI into segments
$segments = explode('/', $cleanUri);

// Check the first segment
$firstSegment = isset($segments[0]) ? $segments[0] : '';

// If the first segment is 'index.php', get the second segment
if ($firstSegment === 'index.php') {
    $firstSegment = isset($segments[1]) ? $segments[1] : '';
}

?>
<?= view($firstSegment . '/header'); ?>
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        padding: 10px;
        text-align: left;
        border: 1px solid #ddd;
    }

    th {
        background-color: #f4f4f4;
    }
</style>
<div class="container my-5">
    <div class="card shadow p-4">

        <h1>All Leads</h1>
        <table>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th>status</th>

                    <th>Created At</th>

                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($leads)): ?>
                    <?php foreach ($leads as $lead): ?>
                        <tr>
                            <td><?= esc($lead['firstName']) ?></td>
                            <td><?= esc($lead['lastName']) ?></td>
                            <td><?= esc($lead['email']) ?></td>
                            <td><?= esc($lead['phone']) ?></td>
                            <td><?= esc($lead['message']) ?></td>
                            <td>
                                <?php
                                if ($lead['status'] == 0) {
                                    echo 'New';
                                } elseif ($lead['status'] == 1) {
                                    echo 'Contacted';
                                } elseif ($lead['status'] == 2) {
                                    echo 'Interested';
                                } elseif ($lead['status'] == 3) {
                                    echo 'Closed';
                                }
                                ?>
                            </td>


                            <td><?= date('D M j, Y, g:i A', strtotime($lead['created_at'])) ?></td>
                            <?php

                            if ($firstSegment === 'admin') {
                                if ($lead['claim'] == 1) {
                                    echo '<td>Claimed</td>';
                                } else {
                                    echo '<td>not Claimed</td>';
                                }
                            } else { ?>

                                <td><button data-id="<?= $lead['id'] ?>" class="claim_btn btn <?php
                                  if ($lead['claim'] == 1) {
                                      echo 'disabled btn-secondary';
                                  } else {
                                      echo ' btn-success';
                                  }
                                  ?>"><?php
                                  if ($lead['claim'] == 1) {
                                      echo 'Already Claimed';
                                  } else {
                                      echo 'Claim';
                                  }
                                  ?></button></td>
                                <?php
                            }
                            ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No leads found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $(".claim_btn").on("click", function () {
            const button = $(this); // Store the clicked button
            const leadId = button.data("id");

            if (!button.hasClass('disabled')) {
                $.ajax({
                    url: "/agent/leads/claim", // Replace with your actual route
                    type: "POST",
                    data: { id: leadId },
                    success: function (response) {
                        console.log(response)
                        if (response.success) {
                            // Update button UI
                            button.addClass('disabled btn-secondary').removeClass('btn-success');
                            button.text('Already Claimed');
                            alert(response.message);

                        } else {
                            alert(response.message || "An error occurred while claiming the lead.");
                        }
                    },
                    error: function () {
                        alert("Failed to communicate with the server.");
                    },
                });
            }
        });
    });
</script>


<?= view($firstSegment . '/footer'); ?>