<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Real Estate </title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
</head>

<style>
    body {
        box-sizing: border-box;
        margin: 0px;
        padding: 0px;
    }

    a *, a:hover *, a *:hover{
        text-decoration: none;
        color: black;
    }

    .slick-slider .element {
        height: calc(100vh - 88px);
        width: 100vw;
        color: #fff;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }

    .element-1 {
        background: linear-gradient(to right, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(/images/hero1.jpg);
    }

    .element-2 {
        background: linear-gradient(to right, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(/images/hero2.jpeg);
    }

    .element-3 {
        background: linear-gradient(to right, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(/images/hero3.jpg);
    }

    .slick-slider .slick-disabled {
        opacity: 0;
        pointer-events: none;
    }

    body {
        background: #eee;
    }

    .gradient-brand-color {
        background-image: -webkit-linear-gradient(0deg, #376be6 0%, #6470ef 100%);
        background-image: -ms-linear-gradient(0deg, #376be6 0%, #6470ef 100%);
        color: #fff;
    }

    .contact-info__wrapper {
        overflow: hidden;
        border-radius: .625rem .625rem 0 0
    }

    @media (min-width: 1024px) {
        .contact-info__wrapper {
            border-radius: 0 .625rem .625rem 0;
            padding: 5rem !important
        }
    }

    .contact-info__list span.position-absolute {
        left: 0
    }

    .z-index-101 {
        z-index: 101;
    }

    .list-style--none {
        list-style: none;
    }

    .contact__wrapper {
        background-color: #fff;
        border-radius: 0 0 .625rem .625rem
    }

    @media (min-width: 1024px) {
        .contact__wrapper {
            border-radius: .625rem 0 .625rem .625rem
        }
    }

    @media (min-width: 1024px) {
        .contact-form__wrapper {
            padding: 5rem !important
        }
    }

    .shadow-lg {
        box-shadow: 0 1rem 3rem rgba(132, 138, 163, 0.1) !important;
    }
</style>

<body>
    <?php if (session()->get('success')): ?>
        <div class="alert alert-success"><?= session()->get('success') ?></div>
    <?php elseif (session()->get('errors')): ?>
        <div class="alert alert-danger">
            <?php foreach (session()->get('errors') as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <nav class="navbar navbar-light bg-light">
        <div class="container py-3">
            <span class="navbar-brand mb-0 h1">Real Estate Management</span>
        </div>
    </nav>
    <div class="slick-slider">
        <div class="element element-1">
            <h1>Find Your Dream Home with Listings You'll Love and Agents You Trust.</h1>
            <p>Discover perfect properties that match your lifestyle, with expert agents guiding you every step of the
                way to finding a place you’ll love to call home.</p>
        </div>
        <div class="element element-2">
            <h1>Find Your Dream Home with Listings You'll Love and Agents You Trust.</h1>
            <p>Discover perfect properties that match your lifestyle, with expert agents guiding you every step of the
                way to finding a place you’ll love to call home.</p>
        </div>
        <div class="element element-3">
            <h1>Find Your Dream Home with Listings You'll Love and Agents You Trust.</h1>
            <p>Discover perfect properties that match your lifestyle, with expert agents guiding you every step of the
                way to finding a place you’ll love to call home.</p>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <h1 class="col-12 text-center mb-5">ALL PROPERTIES</h1>
            <div class="container">
                <div class="row">
                    <?php if (!empty($properties)): ?>
                        <?php foreach ($properties as $property): ?>
                            <div class="col-md-4">
                                <a href="property/internal/<?= $property['id'] ?>" class="card">
                                    <!-- Images -->
                                    <?php
                                    $images = json_decode($property['images'], true); // Assuming images are stored as JSON array
                                    if (!empty($images)): ?>
                                        <img src="<?= $images[0] ?>" class="card-img-top" alt="Property Image"
                                            style="height: 200px; object-fit: cover;">
                                    <?php endif; ?>

                                    <div class="card-body">
                                        <!-- Title and Price -->
                                        <h5 class="card-title"><?= $property['title'] ?></h5>
                                        <p class="card-text">
                                            <strong>Price:</strong> $<?= $property['price'] ?><br>
                                            <strong>Address:</strong> <?= $property['address'] ?><br>
                                            <strong>Type:</strong> <?= ucfirst($property['type']) ?>
                                        </p>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12">
                            <p>No properties found.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="container my-5">
        <div class="contact__wrapper shadow-lg mt-n9">
            <div class="row no-gutters">
                <div class="col-lg-5 contact-info__wrapper gradient-brand-color p-5 order-lg-2">
                    <h3 class="color--white mb-5">Contact</h3>

                    <ul class="contact-info__list list-style--none position-relative z-index-101">
                        <li class="mb-4 pl-4">
                            <span class="position-absolute"><i class="fas fa-envelope"></i></span> test@test.com
                        </li>
                        <li class="mb-4 pl-4">
                            <span class="position-absolute"><i class="fas fa-phone"></i></span> +32 71 123 456
                        </li>
                        <li class="mb-4 pl-4">
                            <span class="position-absolute"><i class="fas fa-map-marker-alt"></i></span> E6K
                            <br> Quai de la gare
                            <br> 6000 Charleroi

                            <div class="mt-3">
                                <a href="https://www.google.com/maps" target="_blank"
                                    class="text-link link--right-icon text-white">Itinéraire <i
                                        class="link__icon fa fa-directions"></i></a>
                            </div>
                        </li>
                    </ul>

                    <figure class="figure position-absolute m-0 opacity-06 z-index-100" style="bottom:0; right: 10px">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="444px"
                            height="626px">
                            <defs>
                                <linearGradient id="PSgrad_1" x1="0%" x2="81.915%" y1="57.358%" y2="0%">
                                    <stop offset="0%" stop-color="rgb(255,255,255)" stop-opacity="1"></stop>
                                    <stop offset="100%" stop-color="rgb(0,54,207)" stop-opacity="0"></stop>
                                </linearGradient>

                            </defs>
                            <path fill-rule="evenodd" opacity="0.302" fill="rgb(72, 155, 248)"
                                d="M816.210,-41.714 L968.999,111.158 L-197.210,1277.998 L-349.998,1125.127 L816.210,-41.714 Z">
                            </path>
                            <path fill="url(#PSgrad_1)"
                                d="M816.210,-41.714 L968.999,111.158 L-197.210,1277.998 L-349.998,1125.127 L816.210,-41.714 Z">
                            </path>
                        </svg>
                    </figure>
                </div>

                <div class="col-lg-7 contact-form__wrapper p-5 order-lg-1">
                    <form action="/inquiry/store" method="post" class="contact-form form-validate">
                        <div class="row">
                            <div class="col-sm-6 mb-3">
                                <div class="form-group">
                                    <label class="required-field" for="firstName">First Name</label>
                                    <input type="text" class="form-control" id="firstName" name="firstName"
                                        placeholder="Jean">
                                </div>
                            </div>

                            <div class="col-sm-6 mb-3">
                                <div class="form-group">
                                    <label for="lastName">Last Name</label>
                                    <input type="text" class="form-control" id="lastName" name="lastName"
                                        placeholder="Dupont">
                                </div>
                            </div>

                            <div class="col-sm-6 mb-3">
                                <div class="form-group">
                                    <label class="required-field" for="email">Email</label>
                                    <input type="text" class="form-control" id="email" name="email"
                                        placeholder="jean@dupont.com">
                                </div>
                            </div>

                            <div class="col-sm-6 mb-3">
                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input type="tel" class="form-control" id="phone" name="phone"
                                        placeholder="+32 71 123 456">
                                </div>
                            </div>

                            <div class="col-sm-12 mb-3">
                                <div class="form-group">
                                    <label class="required-field" for="message">Your Query?</label>
                                    <textarea class="form-control" id="message" name="message" rows="4"
                                        placeholder="Hello, I would like to know about…"></textarea>
                                </div>
                            </div>

                            <div class="col-sm-12 mb-3">
                                <button type="submit" name="submit" class="btn btn-primary">Enquire</button>
                            </div>

                        </div>
                    </form>
                </div>
                <!-- End Contact Form Wrapper -->

            </div>
        </div>
    </div>

    <footer class=" bg-secondary py-2">
        <p class="text-center mb-0 text-white">2024 ALL RIGHTS RESERVED</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/jquery.slick/1.4.1/slick.min.js"></script>
    <script>
        $(".slick-slider").slick({
            slidesToShow: 1,
            infinite: false,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000,
            dots: false,
            arrows: false, // Set to false to remove the previous and next buttons
        });


    </script>
</body>

</html>