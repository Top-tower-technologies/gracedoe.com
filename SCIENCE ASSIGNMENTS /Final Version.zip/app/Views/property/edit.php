<?= view('admin/header');

?>

<?php
// Get the full request URI
$requestUri = $_SERVER['REQUEST_URI'];

// Remove any query parameters
$cleanUri = strtok($requestUri, '?');

// Trim leading and trailing slashes
$cleanUri = trim($cleanUri, '/');

// Split the URI into segments
$segments = explode('/', $cleanUri);

// Check the first segment
$firstSegment = isset($segments[0]) ? $segments[0] : '';

// If the first segment is 'index.php', get the second segment
if ($firstSegment === 'index.php') {
    $firstSegment = isset($segments[1]) ? $segments[1] : '';
}

?>

<div class="container mt-5">
    <h2 class="mb-4">Edit Property</h2>

    <form method="post" action="/<?= $firstSegment ?>/property/update/<?= $property['id'] ?>"
        enctype="multipart/form-data">
        <!-- Title Field -->
        <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control" id="title" name="title" value="<?= $property['title'] ?>" required>
        </div>

        <!-- Images Field -->
        <div class="mb-3">
            <label for="images" class="form-label">Images</label>
            <input type="file" class="form-control" id="images" name="images[]" multiple>
            <small class="form-text text-muted">You can upload multiple images. Existing images will not be removed
                unless uploaded again.</small>
        </div>

        <!-- Description Field -->
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" rows="3"
                required><?= $property['description'] ?></textarea>
        </div>

        <!-- Price Field -->
        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="text" class="form-control" id="price" name="price" value="<?= $property['price'] ?>" required>
        </div>

        <!-- Address Field -->
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <input type="text" class="form-control" id="address" name="address" value="<?= $property['address'] ?>"
                required>
        </div>

        <input type="hidden" name="agent_id" value="<?= $property['agent_id'] ?>">
        <!-- Assuming agent_id should remain unchanged -->

        <!-- Property Type Field (Radio buttons for sell or rent) -->
        <div class="mb-3">
            <label for="type" class="form-label">Property Type</label>
            <div>
                <input type="radio" id="sell" name="type" value="sell" <?= ($property['type'] == 'sell') ? 'checked' : '' ?> required>
                <label for="sell" class="form-label">Sell</label>
            </div>
            <div>
                <input type="radio" id="rent" name="type" value="rent" <?= ($property['type'] == 'rent') ? 'checked' : '' ?> required>
                <label for="rent" class="form-label">Rent</label>
            </div>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?= view('admin/footer'); ?>