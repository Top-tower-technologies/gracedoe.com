<?php
// Get the full request URI
$requestUri = $_SERVER['REQUEST_URI'];

// Remove any query parameters
$cleanUri = strtok($requestUri, '?');

// Trim leading and trailing slashes
$cleanUri = trim($cleanUri, '/');

// Split the URI into segments
$segments = explode('/', $cleanUri);

// Check the first segment
$firstSegment = isset($segments[0]) ? $segments[0] : '';

// If the first segment is 'index.php', get the second segment
if ($firstSegment === 'index.php') {
    $firstSegment = isset($segments[1]) ? $segments[1] : '';
}

?>
<?= view($firstSegment . '/header'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Add Property</h2>

    <form method="post" action="/<?= $firstSegment ?>/property/store" enctype="multipart/form-data">
        <div class="row">
            <!-- Title Field -->
            <div class="col-md-6 mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" placeholder="Enter property title"
                    required>
            </div>

            <!-- Price Field -->
            <div class="col-md-6 mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="text" class="form-control" id="price" name="price" placeholder="Enter property price"
                    required>
            </div>
        </div>

        <div class="row">
            <!-- Images Field -->
            <div class="col-md-6 mb-3">
                <label for="images" class="form-label">Images</label>
                <input type="file" class="form-control" id="images" name="images[]" multiple required>
                <small class="form-text text-muted">You can upload multiple images.</small>
            </div>

            <!-- Address Field -->
            <div class="col-md-6 mb-3">
                <label for="address" class="form-label">Address</label>
                <input type="text" class="form-control" id="address" name="address" placeholder="Enter property address"
                    required>
            </div>
        </div>

        <!-- Description Field -->
        <div class="row">
            <div class="col-12 mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"
                    placeholder="Enter property description" required></textarea>
            </div>
        </div>

        <!-- Hidden Agent ID (for admin assigning agent) -->
        <input type="hidden" name="agent_id" value="1">

        <!-- Property Type Field (Radio buttons for sell or rent) -->
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="type" class="form-label">Property Type</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" id="sell" name="type" value="sell" required>
                    <label class="form-check-label" for="sell">Sell</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" id="rent" name="type" value="rent" required>
                    <label class="form-check-label" for="rent">Rent</label>
                </div>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="row mb-5">
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
</div>

<?= view($firstSegment . '/footer'); ?>