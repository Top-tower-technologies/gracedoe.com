<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Real Estate </title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
</head>

<style>
    body {
        box-sizing: border-box;
        margin: 0px;
        padding: 0px;
    }

    .slick-slider .element {
        height: calc(100vh - 88px);
        width: 100vw;
        color: #fff;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }

    .element-1 {
        background: linear-gradient(to right, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(/images/hero1.jpg);
    }

    .element-2 {
        background: linear-gradient(to right, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(/images/hero2.jpeg);
    }

    .element-3 {
        background: linear-gradient(to right, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(/images/hero3.jpg);
    }

    .slick-slider .slick-disabled {
        opacity: 0;
        pointer-events: none;
    }

    body {
        background: #eee;
    }

    .gradient-brand-color {
        background-image: -webkit-linear-gradient(0deg, #376be6 0%, #6470ef 100%);
        background-image: -ms-linear-gradient(0deg, #376be6 0%, #6470ef 100%);
        color: #fff;
    }

    .contact-info__wrapper {
        overflow: hidden;
        border-radius: .625rem .625rem 0 0
    }

    @media (min-width: 1024px) {
        .contact-info__wrapper {
            border-radius: 0 .625rem .625rem 0;
            padding: 5rem !important
        }
    }

    .contact-info__list span.position-absolute {
        left: 0
    }

    main {
        min-height: calc(100vh - 128px);
    }

    .z-index-101 {
        z-index: 101;
    }

    .list-style--none {
        list-style: none;
    }

    .contact__wrapper {
        background-color: #fff;
        border-radius: 0 0 .625rem .625rem
    }

    @media (min-width: 1024px) {
        .contact__wrapper {
            border-radius: .625rem 0 .625rem .625rem
        }
    }

    @media (min-width: 1024px) {
        .contact-form__wrapper {
            padding: 5rem !important
        }
    }

    .shadow-lg {
        box-shadow: 0 1rem 3rem rgba(132, 138, 163, 0.1) !important;
    }
</style>

<body>
    <?php if (session()->get('success')): ?>
        <div class="alert alert-success"><?= session()->get('success') ?></div>
    <?php elseif (session()->get('errors')): ?>
        <div class="alert alert-danger">
            <?php foreach (session()->get('errors') as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <nav class="navbar navbar-light bg-light">
        <a href="/" class="container py-3">
            <span class="navbar-brand mb-0 h1">Real Estate Management</span>
        </a>
    </nav>

    <main>
        <div class="container">
            <div class="row py-5">
                <div class="col-md-6 d-flex  justify-content-center align-items-center">
                    <!-- Images -->
                    <?php
                    $images = json_decode($property['images'], true); // Assuming images are stored as JSON array
                    if (!empty($images)): ?>
                        <img src="<?= $images[0] ?>" alt="" class="img-fluid">
                    <?php endif; ?>

                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title text-primary mb-3"><?= htmlspecialchars($property['title']) ?></h5>
                            <p class="card-text text-muted">
                                <p><strong>Description:</strong>
                                <?= nl2br(htmlspecialchars($property['description'])) ?></p>
                                <p><strong>Price:</strong> <span
                                    class="text-success">$<?= number_format($property['price'], 2) ?></span></p>
                                <p><strong>Address:</strong> <?= htmlspecialchars($property['address']) ?></p>
                                <p><strong>Type:</strong> <span
                                    class="badge bg-info text-light"><?= ucfirst(htmlspecialchars($property['type'])) ?></span></p>
                                <strong>Added On:</strong>
                                <span class="text-secondary">
                                    <?= date('F j, Y, g:i A', strtotime($property['created_at'])) ?>
                                </span>
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>


    <footer class=" bg-secondary py-2">
        <p class="text-center mb-0 text-white">2024 ALL RIGHTS RESERVED</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/jquery.slick/1.4.1/slick.min.js"></script>

</body>

</html>