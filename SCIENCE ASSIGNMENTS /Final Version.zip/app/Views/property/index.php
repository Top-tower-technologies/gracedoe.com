<?= view('admin/header'); ?>
<div class="container mt-5">
    <h2 class="mb-4">Property Listings</h2>
    <a href="/admin/property/create" class="btn btn-primary mb-4">Add New Property</a>

    <div class="row mb-4 search-box">
        <form action="/admin/property" method="get" class="col-12 d-flex align-items-center justify-content-center">
            <input type="text" name="query" class="form-control" placeholder="Search properties...">
            <button class="btn btn-secondary"><i class="fa fa-search mx-3"></i></button>
        </form>
    </div>

    <div class="row">
        <?php if (!empty($properties)): ?>
            <?php foreach ($properties as $property): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <!-- Images -->
                        <?php
                        $images = json_decode($property['images'], true); // Assuming images are stored as JSON array
                        if (!empty($images)): ?>
                            <img src="<?= $images[0] ?>" class="card-img-top" alt="Property Image"
                                style="height: 200px; object-fit: cover;">
                        <?php endif; ?>

                        <div class="card-body">
                            <!-- Title and Price -->
                            <h5 class="card-title"><?= $property['title'] ?></h5>
                            <p class="card-text">
                                <strong>Price:</strong> $<?= $property['price'] ?><br>
                                <strong>Address:</strong> <?= $property['address'] ?><br>
                                <strong>Type:</strong> <?= ucfirst($property['type']) ?>
                            </p>

                            <!-- Buttons -->
                            <a href="/admin/property/edit/<?= $property['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="/admin/property/delete/<?= $property['id'] ?>" class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure you want to delete this property?');">Delete</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <p>No properties found.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= view('admin/footer'); ?>