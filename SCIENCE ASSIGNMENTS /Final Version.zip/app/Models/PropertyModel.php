<?php

namespace App\Models;

use CodeIgniter\Model;


class PropertyModel extends Model
{
    protected $table = 'properties'; // Your database table name
    protected $primaryKey = 'id';     // Primary key of the table
    protected $allowedFields = [
        'title',
        'description',
        'price',
        'address',
        'agent_id',
        'type',
        'images'
    ]; // Fields that can be mass assigned
}