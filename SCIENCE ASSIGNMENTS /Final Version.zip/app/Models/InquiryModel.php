<?php

namespace App\Models;
use CodeIgniter\Model;

class InquiryModel extends Model
{
    protected $table = 'inquiries';
    protected $primaryKey = 'id';
    protected $allowedFields = ['property_id', 'firstName', 'lastName', 'email', 'phone', 'message', 'claim', 'agent_id', 'status'];
}
