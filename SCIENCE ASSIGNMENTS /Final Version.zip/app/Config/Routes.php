<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');  // Home page or dashboard

// Inquiry routes
$routes->group('inquiry', function ($routes) {
    $routes->get('/', 'InquiryController::index');         // List inquiries
    $routes->post('store', 'InquiryController::store');    // Store new inquiry
});

// Agent routes
$routes->group('agent', function ($routes) {
    $routes->get('login', 'AgentController::login');                // Show login form
    $routes->post('authenticate', 'AgentController::authenticate'); // Handle login submission
    $routes->get('logout', 'AgentController::logout');              // Logout route

    // Authenticated agent routes
    $routes->group('', ['filter' => 'auth'], function ($routes) {
        $routes->get('/', 'AgentController::index');              // Dashboard or list agents
        $routes->get('property', 'AgentController::index');              // Dashboard or list agents

        $routes->get('property/create', 'PropertyController::create'); // Create property form
        $routes->post('property/store', 'PropertyController::store');  // Store new property
        $routes->get('property/edit/(:num)', 'PropertyController::edit/$1'); // Edit property form
        $routes->post('property/update/(:num)', 'PropertyController::update/$1'); // Update property
        $routes->get('property/delete/(:num)', 'PropertyController::delete/$1');  // Delete property

        $routes->get('leads', 'InquiryController::leads'); // Create property form
        $routes->get('claimed', 'InquiryController::claimed'); // Create property form
        $routes->post('leads/claim', 'InquiryController::claimLead'); // Create property form
        $routes->post('leads/Unclaim', 'InquiryController::UnclaimLead'); // Create property form
        $routes->post('leads/updateStatus', 'InquiryController::updateStatus'); // Create property form


    });
});

// Admin routes
$routes->group('admin', function ($routes) {
    $routes->get('login', 'AdminController::login');                // Show login form
    $routes->post('authenticate', 'AdminController::authenticate'); // Handle login submission
    $routes->get('logout', 'AdminController::logout');              // Logout route

    // Authenticated admin routes
    $routes->group('', ['filter' => 'auth'], function ($routes) {
        $routes->get('property', 'AdminController::index');                  // Dashboard
        $routes->get('users', 'AdminController::users');              // List users
        $routes->get('settings', 'AdminController::settings');        // Settings page

        // Property routes
        $routes->get('/', 'PropertyController::index');         // List properties
        $routes->get('property/create', 'PropertyController::create'); // Create property form
        $routes->post('property/store', 'PropertyController::store');  // Store new property
        $routes->get('property/edit/(:num)', 'PropertyController::edit/$1'); // Edit property form
        $routes->post('property/update/(:num)', 'PropertyController::update/$1'); // Update property
        $routes->get('property/delete/(:num)', 'PropertyController::delete/$1');  // Delete property

        // Agent routes
        $routes->get('agents', 'AgentController::agents');             // List agents
        $routes->get('agents/create', 'AgentController::create');      // Create agent form
        $routes->post('agents/store', 'AgentController::store');       // Store new agent
        $routes->get('agents/edit/(:num)', 'AgentController::edit/$1');// Edit agent form
        $routes->post('agent/update/(:num)', 'AgentController::update/$1'); // Update agent
        $routes->get('agents/delete/(:num)', 'AgentController::delete/$1');  // Delete agent

        // leads route
        $routes->get('leads', 'InquiryController::leads');

    });
});
