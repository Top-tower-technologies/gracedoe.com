<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Check if the session has admin or agent login
        $isAdmin = session()->get('logged_in_admin');
        $isAgent = session()->get('logged_in_agent');

        // Get the current URI path
        $path = $request->getUri()->getPath();

        // Determine if the request is for admin or agent area and redirect accordingly
        if (!$isAdmin && strpos($path, 'admin') === 0) {
            // Redirect to admin login if not logged in as admin
            return redirect()->to('/admin/login')->with('error', 'Please log in as admin.');
        }

        if (!$isAgent && strpos($path, 'agent') === 0) {
            // Redirect to agent login if not logged in as agent
            return redirect()->to('/agent/login')->with('error', 'Please log in first.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No post-response action needed
    }
}
